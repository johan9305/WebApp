from distutils.core import setup
setup(         name         = 'Dealing' ,         version      = '0.1',         py_modules   = ['Dealing'] ,        author       = 'JV',        author_email = 'johan5618@hotmail.com',        url          = 'Dealing.py',        description  = 'A simple module to manage a clients list',     )
